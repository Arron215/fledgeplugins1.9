************************
Fledge South playback
************************

This directory contains a South plugin that we would like to have a south plugin that would read a file and present it as if it was coming from a sensor.

The file format should be a CSV file, with options to allow different formatting of that file and different presentation of the readings to Fledge.

