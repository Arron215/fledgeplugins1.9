***************************
Fledge South CoAP Listener
***************************

This directory contains a South plugin that implements the CoAP protocol
and listens for incoming sensor readings sent to Fledge by sensors
that implement the CoAP protocol. This CoAP implementation is purely a
passive CoAP implementation, it does not pull readings from sensors or
actively discover or connect to sensors.


## CoAP Readings Payload