========================
Fledge South systeminfo
========================

This directory contains a South plugin that fetches System Info at defined intervals.

Installation
------------

The plugin can be installed with given `requirements.sh <../../../../../requirements.sh>`_ or the following steps:


.. code-block:: bash

   $ sudo apt install -y sysstat
