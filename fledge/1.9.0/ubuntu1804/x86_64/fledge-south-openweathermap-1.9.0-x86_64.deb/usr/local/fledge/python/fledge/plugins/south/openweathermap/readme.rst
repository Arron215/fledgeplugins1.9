****************************
Fledge South OpenWeatherMap
****************************

This directory contains a South service plugin that fetches weather report from
OpenWeatherMap API on a regular (configured default to 10 seconds) interval.

