-- Remove configuration category_children table
DROP TABLE IF EXISTS fledge.category_children;