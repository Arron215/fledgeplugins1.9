CREATE INDEX readings_ix2
    ON readings (asset_code);
