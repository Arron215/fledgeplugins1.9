-- Remove plugin_data table
DROP TABLE IF EXISTS fledge.plugin_data;
