-- Notification log codes
DELETE from fledge.log_codes WHERE code = 'NTFAD';
DELETE from fledge.log_codes WHERE code = 'NTFSN';
DELETE from fledge.log_codes WHERE code = 'NTFST';
DELETE from fledge.log_codes WHERE code = 'NTFSD';
