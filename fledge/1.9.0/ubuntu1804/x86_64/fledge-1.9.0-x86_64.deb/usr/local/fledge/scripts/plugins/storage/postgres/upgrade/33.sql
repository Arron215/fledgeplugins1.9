INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'PKGRM', 'Package purged' );