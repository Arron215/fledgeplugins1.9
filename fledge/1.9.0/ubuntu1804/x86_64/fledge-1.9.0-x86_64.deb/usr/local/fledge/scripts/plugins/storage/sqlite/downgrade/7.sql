-- Remove asset_tracker table and index
DROP TABLE IF EXISTS fledge.asset_tracker;
DROP INDEX IF EXISTS asset_tracker_ix1;
DROP INDEX IF EXISTS asset_tracker_ix2;