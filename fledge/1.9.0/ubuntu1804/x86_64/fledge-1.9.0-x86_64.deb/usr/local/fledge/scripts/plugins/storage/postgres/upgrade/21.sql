-- Notification log codes
INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'NTFAD', 'Notification Added' );

INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'NTFSN', 'Notification Sent' );

INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'NTFST', 'Notification Server Startup' );

INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'NTFSD', 'Notification Server Shutdown' );
