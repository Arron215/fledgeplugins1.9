INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'PKGIN', 'Package installation' ), ( 'PKGUP', 'Package updated' );
