DROP INDEX readings_ix3;
