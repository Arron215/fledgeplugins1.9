CREATE INDEX statistics_history_ix3
    ON statistics_history (history_ts);
