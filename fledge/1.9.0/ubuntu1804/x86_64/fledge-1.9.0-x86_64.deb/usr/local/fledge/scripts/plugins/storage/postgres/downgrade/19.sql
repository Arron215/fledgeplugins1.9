DROP TABLE fledge.filters;
DROP TABLE fledge.filter_users;
