***********************
Fledge South RandomWalk
***********************

This directory contains a South plugin that generates random walk data points.
